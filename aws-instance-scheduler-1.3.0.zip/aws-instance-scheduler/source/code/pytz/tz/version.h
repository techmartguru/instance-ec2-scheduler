static char const PKGVERSION[]="(tzcode) ";
static char const TZVERSION[]="unknown";
static char const REPORT_BUGS_TO[]="tz@iana.org";
